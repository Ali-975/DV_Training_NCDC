#!/bin/bash
# Custom Git Simulator Script

BACKUP_DIR="../files/.task_3_mygit_backup"
STATUS_FILE="../files/.task_3_status"

# Function to simulate git init
git_init() {
    echo "Initializing custom git repository..."
    
    # Create backup directory if it doesn't exist
    if [ -d "$BACKUP_DIR" ]; then
        echo "Repository already initialized!"
        return 1
    fi
    
    mkdir -p "$BACKUP_DIR"
    
    # Create initial backup of current directory
    echo "Creating initial backup..."
    
    # Copy all files (excluding hidden files and the backup directory itself)
    find . -maxdepth 1 -type f ! -name ".*" -exec cp {} "$BACKUP_DIR/" \;
    
    # Create status file to track initialization
    echo "$(date): Repository initialized" > "$STATUS_FILE"
    
    echo "Custom git repository initialized successfully in $(pwd)"
    echo "Backup created in $BACKUP_DIR directory"
    
    return 0
}

# Function to simulate git status
git_status() {
    echo "Checking repository status..."
    echo ""
    
    # Check if repository is initialized
    if [ ! -d "$BACKUP_DIR" ]; then
        echo "Error: Not a git repository (or any of the parent directories)"
        echo "Run '$0 init' to initialize a repository"
        return 1
    fi
    
    echo "On branch master"
    echo ""
    
    local changes_found=0
    local new_files=0
    local modified_files=0
    local deleted_files=0
    
    # Arrays to store different types of changes
    declare -a new_files_list
    declare -a modified_files_list
    declare -a deleted_files_list
    
    # Check for new files (files in current directory but not in backup)
    for file in *; do
        if [ -f "$file" ] && [ ! -f "$BACKUP_DIR/$file" ]; then
            new_files_list+=("$file")
            ((new_files++))
            changes_found=1
        fi
    done
    
    # Check for modified files (files that exist in both but are different)
    for file in "$BACKUP_DIR"/*; do
        if [ -f "$file" ]; then
            filename=$(basename "$file")
            if [ -f "$filename" ]; then
                # Compare files using diff
                if ! diff -q "$file" "$filename" >/dev/null 2>&1; then
                    modified_files_list+=("$filename")
                    ((modified_files++))
                    changes_found=1
                fi
            fi
        fi
    done
    
    # Check for deleted files (files in backup but not in current directory)
    for file in "$BACKUP_DIR"/*; do
        if [ -f "$file" ]; then
            filename=$(basename "$file")
            if [ ! -f "$filename" ]; then
                deleted_files_list+=("$filename")
                ((deleted_files++))
                changes_found=1
            fi
        fi
    done
    
    # Display results
    if [ $changes_found -eq 0 ]; then
        echo "No changes detected."
        echo "Working tree clean"
    else
        if [ $new_files -gt 0 ]; then
            echo "Untracked files:"
            echo "  (use \"git add <file>...\" to include in what will be committed)"
            echo ""
            for file in "${new_files_list[@]}"; do
                echo -e "\t\033[31m$file\033[0m"  # Red color for new files
            done
            echo ""
        fi
        
        if [ $modified_files -gt 0 ]; then
            echo "Changes not staged for commit:"
            echo "  (use \"git add <file>...\" to update what will be committed)"
            echo "  (use \"git checkout -- <file>...\" to discard changes in working directory)"
            echo ""
            for file in "${modified_files_list[@]}"; do
                echo -e "\t\033[31mmodified:   $file\033[0m"  # Red color for modified files
            done
            echo ""
        fi
        
        if [ $deleted_files -gt 0 ]; then
            echo "Changes not staged for commit:"
            echo "  (use \"git add/rm <file>...\" to update what will be committed)"
            echo "  (use \"git checkout -- <file>...\" to discard changes in working directory)"
            echo ""
            for file in "${deleted_files_list[@]}"; do
                echo -e "\t\033[31mdeleted:    $file\033[0m"  # Red color for deleted files
            done
            echo ""
        fi
        
        echo "Summary: $new_files new, $modified_files modified, $deleted_files deleted"
    fi
    
    return 0
}

# Function to update backup (simulate git add)
git_add() {
    if [ ! -d "$BACKUP_DIR" ]; then
        echo "Error: Not a git repository"
        return 1
    fi
    
    echo "Updating backup with current changes..."
    
    # Update backup with current files
    rm -rf "$BACKUP_DIR"/*
    find . -maxdepth 1 -type f ! -name ".*" -exec cp {} "$BACKUP_DIR/" \;
    
    echo "$(date): Backup updated" >> "$STATUS_FILE"
    echo "Changes staged successfully!"
}

# Main script logic
case "$1" in
    "init")
        git_init
        ;;
    "status")
        git_status
        ;;
    "add")
        git_add
        ;;
    "help"|"-h"|"--help")
        echo "Custom Git Simulator"
        echo ""
        echo "Usage: $0 [command]"
        echo ""
        echo "Commands:"
        echo "  init     Initialize a new repository"
        echo "  status   Show the working tree status"
        echo "  add      Stage all changes"
        echo "  help     Show this help message"
        ;;
    *)
        echo "Custom Git Simulator"
        echo ""
        echo "Usage: $0 [command]"
        echo ""
        echo "Available commands: init, status, add, help"
        echo "Run '$0 help' for more information"
        ;;
esac