#!/bin/bash
# Random Password Generator Script
generate_password() {
    local length=$1

    # Character sets
    lowercase="abcdefghijklmnopqrstuvwxyz"
    uppercase="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    numbers="0123456789"
    special="!@#$%^&*()_+-=[]{}|;:,.<>?"

    # Combine all characters
    all_chars="${lowercase}${uppercase}${numbers}${special}"

    # Generate password
    password=""
    for ((i=0; i<length; i++)); do
        # Get random index
        rand_index=$((RANDOM % ${#all_chars}))
        # Extract character at random index
        password="${password}${all_chars:$rand_index:1}"
    done

    echo "$password"
}

# Function to validate password strength
validate_password() {
    local password=$1
    local has_lower=0
    local has_upper=0
    local has_digit=0
    local has_special=0

    # Check for different character types
    if [[ "$password" =~ [a-z] ]]; then has_lower=1; fi
    if [[ "$password" =~ [A-Z] ]]; then has_upper=1; fi
    if [[ "$password" =~ [0-9] ]]; then has_digit=1; fi
    if [[ "$password" =~ [^a-zA-Z0-9] ]]; then has_special=1; fi

    echo "Password Analysis:"
    echo "  Contains lowercase: $([ $has_lower -eq 1 ] && echo "Yes" || echo "No")"
    echo "  Contains uppercase: $([ $has_upper -eq 1 ] && echo "Yes" || echo "No")"
    echo "  Contains digits: $([ $has_digit -eq 1 ] && echo "Yes" || echo "No")"
    echo "  Contains special chars: $([ $has_special -eq 1 ] && echo "Yes" || echo "No")"

    local strength=$((has_lower + has_upper + has_digit + has_special))
    case $strength in
        4) echo "  Strength: Very Strong" ;;
        3) echo "  Strength: Strong" ;;
        2) echo "  Strength: Medium" ;;
        1) echo "  Strength: Weak" ;;
        0) echo "  Strength: Very Weak" ;;
    esac
}

# Main script
echo "==========================================="
echo "   Welcome to Random Password Generator"
echo "==========================================="
echo ""

# Get password length from user
while true; do
    echo -n "Enter desired password length (minimum 4, maximum 20): "
    read length

    # Validate input
    if ! [[ "$length" =~ ^[0-9]+$ ]]; then
        echo "Error: Please enter a valid number!"
        continue
    fi

    if [ "$length" -lt 4 ]; then
        echo "Error: Password length must be at least 4 characters!"
        continue
    fi

    if [ "$length" -gt 128 ]; then
        echo "Error: Password length cannot exceed 128 characters!"
        continue
    fi

    break
done

echo ""
echo "Generating password of length $length..."
echo ""

# Generate password
password=$(generate_password $length)

echo "Generated Password: $password"
echo ""

# Validate and analyze password
validate_password "$password"

echo ""
echo "<< Password generation completed successfully >>"
echo ""

echo "================================================"