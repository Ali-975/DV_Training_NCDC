#!/bin/bash

arr=(64 34 25 12 22 11 90 5 77 30)
echo ""
echo "...Welcome to Bubble Sort Algorithm..."
echo ""
echo "Original array: ${arr[@]}"

# Get array length
n=${#arr[@]}

# Bubble Sort Algorithm Implementation
for ((i = 0; i < n-1; i++)); do

    # Flag to check if any swap occurred in this pass
    swapped=0

    # Last i elements are already in place
    for ((j = 0; j < n-i-1; j++)); do
        # Compare adjacent elements
        if [ ${arr[j]} -gt ${arr[$((j+1))]} ]; then
            # Swap elements
            temp=${arr[j]}
            arr[j]=${arr[$((j+1))]}
            arr[$((j+1))]=$temp
            swapped=1
        fi
    done

    # If no swapping occurred, array is sorted
    if [ $swapped -eq 0 ]; then
        break
    fi
done
echo ""
echo "Final sorted array: ${arr[@]}"
echo ""
echo "...Bubble sort completed successfully..."
echo ""S