#!/bin/bash
# File Type Segregation and Archiving Script

WORK_DIR="../files/task_4_files"

# Function to create directory if it doesn't exist
create_directory() {
    local dir_name="$1"
    if [ ! -d "$dir_name" ]; then
        mkdir -p "$dir_name"
        echo "Created directory: $dir_name"
    else
        echo "Directory already exists: $dir_name"
    fi
}

# Function to move files by extension
move_files_by_extension() {
    local extension="$1"
    local target_dir="$2"
    local moved_count=0
    
    echo ""
    echo "Processing .$extension files..."
    
    # Find and move files with specified extension
    for file in "$WORK_DIR"/*.$extension; do
        # Check if the glob pattern matched any files
        if [ -e "$file" ]; then
            filename=$(basename "$file")
            echo "  Moving: $filename -> $target_dir/"
            mv "$file" "$target_dir/"
            ((moved_count++))
        fi
    done
    
    if [ $moved_count -eq 0 ]; then
        echo "  No .$extension files found in $WORK_DIR"
    else
        echo "  Moved $moved_count .$extension file(s)"
    fi
    
    return $moved_count
}

# Function to create zip archive
create_archive() {
    local source_dir="$1"
    local archive_name="$2"
    
    if [ -d "$source_dir" ] && [ "$(ls -A "$source_dir" 2>/dev/null)" ]; then
        echo ""
        echo "Creating archive: $archive_name"
        
        # Create zip archive
        cd "$WORK_DIR"
        zip -r "$archive_name" "$(basename "$source_dir")" > /dev/null 2>&1
        
        if [ $? -eq 0 ]; then
            echo "  Archive created successfully: $WORK_DIR/$archive_name"
            
            # Show archive contents
            echo "  Archive contents:"
            unzip -l "$archive_name" | tail -n +4 | head -n -2 | while read line; do
                echo "    $line"
            done
        else
            echo "  Error: Failed to create archive"
        fi
        cd - > /dev/null
    else
        echo ""
        echo "Skipping archive creation for $source_dir (empty or doesn't exist)"
    fi
}

# Function to display directory contents
show_directory_structure() {
    echo ""
    echo "Current directory structure:"
    if command -v tree >/dev/null 2>&1; then
        tree "$WORK_DIR" -a
    else
        find "$WORK_DIR" -type d -exec echo "Directory: {}" \;
        find "$WORK_DIR" -type f -exec echo "File: {}" \;
    fi
}

# Function to create sample files for demonstration
create_sample_files() {
    echo "Creating sample files for demonstration..."
    
    # Create some sample PDF files
    touch "$WORK_DIR/document1.pdf"
    touch "$WORK_DIR/manual.pdf"
    touch "$WORK_DIR/report.pdf"
    
    # Create some sample C files
    echo '#include <stdio.h>
    int main() {
        printf("Hello World\\n");
        return 0;
    }' > "$WORK_DIR/hello.c"
    
    echo '#include <stdio.h>
    void function1() {
        printf("Function 1\\n");
    }' > "$WORK_DIR/utils.c"
    
    # Create some sample header files
    echo '#ifndef UTILS_H
    #define UTILS_H
    void function1();
    #endif' > "$WORK_DIR/utils.h"
    
    echo '#ifndef MAIN_H
    #define MAIN_H
    int main();
    #endif' > "$WORK_DIR/main.h"
    
    # Create some other files
    touch "$WORK_DIR/readme.txt"
    touch "$WORK_DIR/data.json"
    
    echo "Sample files created successfully!"
}

# Main script execution
echo "========================================"
echo "  File Type Segregation and Archiving  "
echo "========================================"
echo ""

# Check if files directory exists
if [ ! -d "$WORK_DIR" ]; then
    echo "Creating $WORK_DIR directory..."
    mkdir -p "$WORK_DIR"
fi

# Ask user if they want to create sample files
if [ -z "$(ls -A "$WORK_DIR" 2>/dev/null)" ]; then
    echo "The $WORK_DIR directory is empty."
    echo -n "Would you like to create sample files for demonstration? (y/n): "
    read create_samples
    if [[ "$create_samples" =~ ^[Yy]$ ]]; then
        create_sample_files
        echo ""
    fi
fi

# Show initial directory contents
echo "Initial contents of $WORK_DIR:"
ls -la "$WORK_DIR"

# Create subdirectories for different file types
echo ""
echo "Creating subdirectories..."
create_directory "$WORK_DIR/pdf_files"
create_directory "$WORK_DIR/c_files"
create_directory "$WORK_DIR/h_files"

# Move files by extension
pdf_count=$(move_files_by_extension "pdf" "$WORK_DIR/pdf_files"; echo $?)
c_count=$(move_files_by_extension "c" "$WORK_DIR/c_files"; echo $?)
h_count=$(move_files_by_extension "h" "$WORK_DIR/h_files"; echo $?)

echo ""
echo "File segregation completed!"
echo "  PDF files moved: $pdf_count"
echo "  C files moved: $c_count"
echo "  Header files moved: $h_count"

# Create archives for each subdirectory
echo ""
echo "Creating archives..."
create_archive "$WORK_DIR/pdf_files" "pdf_files.zip"
create_archive "$WORK_DIR/c_files" "c_files.zip"
create_archive "$WORK_DIR/h_files" "h_files.zip"

# Show final directory structure
show_directory_structure

echo ""
echo "Final contents of $WORK_DIR:"
ls -la "$WORK_DIR"

echo ""
echo "File segregation and archiving completed successfully!"

# Summary
echo ""
echo "Summary:"
echo "  - Files have been segregated by extension (.pdf, .c, .h)"
echo "  - Separate subdirectories created for each file type"
echo "  - Zip archives created for non-empty subdirectories"
echo "  - All archives are stored in the $WORK_DIR directory"