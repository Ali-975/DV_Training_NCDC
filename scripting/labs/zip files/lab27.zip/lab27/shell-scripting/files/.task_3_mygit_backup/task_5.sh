#!/bin/bash
# Executable Finder and Logger Script

SOURCE_DIR="../files/task_5_files"
LOG_FILE="$SOURCE_DIR/executables.log"

# Function to check if a file is executable
is_executable() {
    local file="$1"
    if [ -f "$file" ] && [ -x "$file" ]; then
        return 0  # True - file is executable
    else
        return 1  # False - file is not executable
    fi
}

# Function to create sample directory structure and files
create_sample_structure() {
    echo "Creating sample directory structure and files..."
    
    # Create source directory and subdirectories
    mkdir -p "$SOURCE_DIR/bin"
    mkdir -p "$SOURCE_DIR/tools"
    mkdir -p "$SOURCE_DIR/scripts"
    mkdir -p "$SOURCE_DIR/lib"
    mkdir -p "$SOURCE_DIR/config"
    
    # Create some executable files
    echo '#!/bin/bash
echo "This is a sample executable script"' > "$SOURCE_DIR/bin/sample_app"
    chmod +x "$SOURCE_DIR/bin/sample_app"
    
    echo '#!/bin/bash
echo "Database backup utility"' > "$SOURCE_DIR/bin/backup_db"
    chmod +x "$SOURCE_DIR/bin/backup_db"
    
    echo '#!/usr/bin/env python3
print("Python executable")' > "$SOURCE_DIR/tools/data_processor"
    chmod +x "$SOURCE_DIR/tools/data_processor"
    
    echo '#!/bin/bash
echo "System monitor"' > "$SOURCE_DIR/tools/monitor"
    chmod +x "$SOURCE_DIR/tools/monitor"
    
    echo '#!/bin/bash
echo "Deploy script"' > "$SOURCE_DIR/scripts/deploy.sh"
    chmod +x "$SOURCE_DIR/scripts/deploy.sh"
    
    echo '#!/bin/bash
echo "Cleanup utility"' > "$SOURCE_DIR/scripts/cleanup"
    chmod +x "$SOURCE_DIR/scripts/cleanup"
    
    # Create some non-executable files
    echo "Configuration file" > "$SOURCE_DIR/config/app.conf"
    echo "Library file" > "$SOURCE_DIR/lib/helper.so"
    echo "Documentation" > "$SOURCE_DIR/README.md"
    echo "Text file" > "$SOURCE_DIR/notes.txt"
    
    # Create a binary-like executable (simulate)
    echo '#!/bin/bash
echo "Simulated binary executable"' > "$SOURCE_DIR/bin/myprogram"
    chmod +x "$SOURCE_DIR/bin/myprogram"
    
    echo "Sample structure created successfully!"
}

# Function to get file type description
get_file_type() {
    local file="$1"
    local first_line=$(head -n1 "$file" 2>/dev/null)
    
    if [[ "$first_line" =~ ^#!/bin/bash ]]; then
        echo "Bash Script"
    elif [[ "$first_line" =~ ^#!/usr/bin/env\ python ]]; then
        echo "Python Script"
    elif [[ "$first_line" =~ ^#!/ ]]; then
        echo "Script ($(echo "$first_line" | cut -d'/' -f3-))"
    elif file "$file" 2>/dev/null | grep -q "ELF"; then
        echo "Binary Executable"
    else
        echo "Executable File"
    fi
}

# Function to find executables in a directory
find_executables_in_dir() {
    local dir="$1"
    local dir_name=$(basename "$dir")
    local executables_found=0
    local output=""
    
    # Find all executable files in the directory
    while IFS= read -r -d '' file; do
        if is_executable "$file"; then
            filename=$(basename "$file")
            file_type=$(get_file_type "$file")
            file_size=$(ls -lh "$file" | awk '{print $5}')
            
            if [ $executables_found -eq 0 ]; then
                output+="\n$dir_name/:\n"
            fi
            
            output+="  $filename [$file_type, Size: $file_size]\n"
            ((executables_found++))
        fi
    done < <(find "$dir" -maxdepth 1 -type f -print0 2>/dev/null)
    
    if [ $executables_found -gt 0 ]; then
        echo -e "$output"
        return $executables_found
    fi
    
    return 0
}

# Function to display statistics
display_statistics() {
    local total_dirs="$1"
    local dirs_with_executables="$2"
    local total_executables="$3"
    
    echo ""
    echo "========================================="
    echo "           SEARCH STATISTICS"
    echo "========================================="
    echo "Total subdirectories scanned: $total_dirs"
    echo "Directories with executables: $dirs_with_executables"
    echo "Total executable files found: $total_executables"
    echo "========================================="
}

# Main script execution
echo "==========================================="
echo "     Executable Finder and Logger"
echo "==========================================="
echo ""

# Check if source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Source directory '$SOURCE_DIR' does not exist."
    echo -n "Would you like to create a sample directory structure? (y/n): "
    read create_sample
    if [[ "$create_sample" =~ ^[Yy]$ ]]; then
        create_sample_structure
        echo ""
    else
        echo "Please create the '$SOURCE_DIR' directory and add some subdirectories with files."
        exit 1
    fi
fi

# Initialize counters
total_directories=0
directories_with_executables=0
total_executables=0

# Initialize log file
echo "Executable Files Search Report" > "$LOG_FILE"
echo "Generated on: $(date)" >> "$LOG_FILE"
echo "Search Directory: $(pwd)/$SOURCE_DIR" >> "$LOG_FILE"
echo "=========================================" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

echo "Searching for executable files in subdirectories of $SOURCE_DIR..."
echo ""

# Check if there are any subdirectories
if [ -z "$(find "$SOURCE_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null)" ]; then
    echo "No subdirectories found in $SOURCE_DIR"
    echo "No subdirectories found in $SOURCE_DIR" >> "$LOG_FILE"
    exit 1
fi

# Search through each subdirectory
for subdir in "$SOURCE_DIR"/*/ ; do
    if [ -d "$subdir" ]; then
        ((total_directories++))
        
        # Find executables in this subdirectory
        result=$(find_executables_in_dir "$subdir")
        executables_count=$?
        
        if [ $executables_count -gt 0 ]; then
            echo "$result"
            echo "$result" >> "$LOG_FILE"
            ((directories_with_executables++))
            ((total_executables += executables_count))
        fi
    fi
done

# Add statistics to log file
echo "" >> "$LOG_FILE"
echo "=========================================" >> "$LOG_FILE"
echo "SEARCH STATISTICS" >> "$LOG_FILE"
echo "=========================================" >> "$LOG_FILE"
echo "Total subdirectories scanned: $total_directories" >> "$LOG_FILE"
echo "Directories with executables: $directories_with_executables" >> "$LOG_FILE"
echo "Total executable files found: $total_executables" >> "$LOG_FILE"
echo "Log generated at: $(date)" >> "$LOG_FILE"

# Display results
if [ $total_executables -eq 0 ]; then
    echo "No executable files found in any subdirectories."
    echo "No executable files found in any subdirectories." >> "$LOG_FILE"
else
    display_statistics "$total_directories" "$directories_with_executables" "$total_executables"
fi

echo ""
echo "Search completed!"
echo "Results have been logged to: $LOG_FILE"

# Show log file location and content preview
echo ""
echo "Log file preview:"
echo "==================="
head -20 "$LOG_FILE"
if [ $(wc -l < "$LOG_FILE") -gt 20 ]; then
    echo "... (truncated, see full log at $LOG_FILE)"
fi