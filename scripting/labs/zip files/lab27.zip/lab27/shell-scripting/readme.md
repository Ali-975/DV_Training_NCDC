# Digital Design Verification - Shell (bash) Scripting
# Lab Manual #27 - Complete Documentation

## Overview
This document provides comprehensive documentation for all five bash scripting tasks completed in Lab Manual #27. Each script demonstrates different aspects of shell scripting including algorithms, user interaction, file operations, and system utilities.

---

## Task 1: Sorting an Array using Bubble Sort

### Script: `task_1.sh`

#### Description
This script implements the Bubble Sort algorithm to sort a hard-coded array of integers. The algorithm repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order.

#### Key Features
- **Hard-coded Array**: Contains integers `(64 34 25 12 22 11 90 5 77 30)`
- **Visual Process**: Shows each pass and swap operation
- **Early Termination**: Stops if no swaps occur (array is already sorted)
- **Progress Tracking**: Displays array state after each pass

#### Algorithm Explanation
1. **Outer Loop**: Runs n-1 times where n is array length
2. **Inner Loop**: Compares adjacent elements
3. **Swapping**: Exchanges elements if left > right
4. **Optimization**: Uses a flag to detect if array is already sorted

#### How to Run
```bash
chmod +x task_1.sh
./task_1.sh
```

#### Expected Output
- Original array display
- Step-by-step sorting process
- Final sorted array
- Completion message

---

## Task 2: Random Password Generator

### Script: `task_2.sh`

#### Description
This script generates secure random passwords with user-specified length, containing lowercase letters, uppercase letters, numbers, and special characters.

#### Key Features
- **User Input Validation**: Ensures length is between 4-128 characters
- **Character Sets**: Includes all character types for security
- **Password Analysis**: Evaluates strength based on character diversity
- **Interactive Interface**: User-friendly prompts and options
- **Repeat Generation**: Option to generate multiple passwords

#### Security Features
- **Minimum Length**: Enforces 4-character minimum
- **Character Variety**: Ensures all character types are available
- **Strength Analysis**: Categorizes password strength
- **Random Generation**: Uses bash RANDOM for character selection

#### How to Run
```bash
chmod +x task_2.sh
./task_2.sh
```

#### Expected Output
- Password length prompt
- Generated password display
- Password strength analysis
- Option to generate another password

---

## Task 3: Git Init and Status Simulator

### Script: `task_3.sh`

#### Description
This script simulates the basic functionality of `git init` and `git status` commands by creating backups and comparing file states.

#### Key Features
- **Repository Initialization**: Creates `.mygit_backup` directory
- **File Tracking**: Monitors new, modified, and deleted files
- **Status Reporting**: Color-coded output similar to git
- **Backup Management**: Maintains snapshot of files for comparison
- **Multiple Commands**: Supports init, status, add, and help

#### Commands Available
1. **init**: Initialize repository and create initial backup
2. **status**: Show differences between backup and current files
3. **add**: Update backup with current changes
4. **help**: Display usage information

#### How to Run
```bash
chmod +x task_3.sh

# Initialize repository
./task_3.sh init

# Check status
./task_3.sh status

# Stage changes
./task_3.sh add
```

#### File Detection Logic
- **New Files**: In current directory but not in backup
- **Modified Files**: Different content between current and backup
- **Deleted Files**: In backup but not in current directory

---

## Task 4: File Type Segregation and Archiving

### Script: `task_4.sh`

#### Description
This script organizes files by their extensions (.pdf, .c, .h) into separate subdirectories and creates zip archives of each category.

#### Key Features
- **Automatic Directory Creation**: Creates subdirectories for each file type
- **File Organization**: Moves files based on extensions
- **Archive Creation**: Creates zip files for each category
- **Sample Data Generation**: Can create test files for demonstration
- **Comprehensive Reporting**: Shows moved files count and structure

#### File Categories
- **PDF Files**: Moved to `files/pdf_files/` → `pdf_files.zip`
- **C Source Files**: Moved to `files/c_files/` → `c_files.zip`
- **Header Files**: Moved to `files/h_files/` → `h_files.zip`

#### How to Run
```bash
chmod +x task_4.sh
./task_4.sh
```

#### Directory Structure Created
```
files/
├── pdf_files/
│   └── *.pdf files
├── c_files/
│   └── *.c files
├── h_files/
│   └── *.h files
├── pdf_files.zip
├── c_files.zip
└── h_files.zip
```

---

## Task 5: Executable Finder and Logger

### Script: `task_5.sh`

#### Description
This script searches for all executable files in subdirectories of the `source/` directory and logs the results to `executables.log`.

#### Key Features
- **Recursive Search**: Scans all subdirectories in source/
- **File Type Detection**: Identifies script types (bash, python, etc.)
- **Detailed Logging**: Records results with timestamps and statistics
- **Sample Structure Generation**: Can create test directory structure
- **Comprehensive Reporting**: Shows file sizes and types

#### Detection Capabilities
- **Bash Scripts**: Identified by `#!/bin/bash` shebang
- **Python Scripts**: Identified by `#!/usr/bin/env python` shebang
- **Binary Executables**: Detected using file command
- **Generic Executables**: Files with execute permission

#### How to Run
```bash
chmod +x task_5.sh
./task_5.sh
```

#### Log File Format
```
Executable Files Search Report
Generated on: [timestamp]
Search Directory: [path]
=========================================

bin/:
  sample_app [Bash Script, Size: 64B]
  backup_db [Bash Script, Size: 58B]

tools/:
  data_processor [Python Script, Size: 45B]
  monitor [Bash Script, Size: 52B]

=========================================
SEARCH STATISTICS
=========================================
Total subdirectories scanned: 5
Directories with executables: 3
Total executable files found: 6
```

---

## General Usage Instructions

### Prerequisites
- Linux/Unix system with bash shell
- Basic commands: `find`, `diff`, `zip`, `chmod`
- Write permissions in current directory

### Installation Steps
1. Save each script to a `.sh` file
2. Make scripts executable: `chmod +x script_name.sh`
3. Run scripts: `./script_name.sh`

### Common Features Across All Scripts
- **Error Handling**: Graceful handling of edge cases
- **User Feedback**: Clear progress messages and results
- **Input Validation**: Checks for valid inputs where applicable
- **Documentation**: Comprehensive comments explaining logic
- **Modularity**: Functions for reusable code blocks

---

## Technical Implementation Details

### Bash Scripting Techniques Used

#### Arrays and Loops
- **Bubble Sort**: Demonstrates array manipulation and nested loops
- **File Processing**: Uses arrays to store and process file lists

#### File Operations
- **File Testing**: `-f`, `-d`, `-x` flags for file type checking
- **File Comparison**: `diff` command for content comparison
- **Directory Operations**: `mkdir`, `find`, `ls` commands

#### User Interaction
- **Input Reading**: `read` command for user input
- **Input Validation**: Pattern matching and range checking
- **Interactive Menus**: Choice-based program flow

#### String Processing
- **Pattern Matching**: Regular expressions for file type detection
- **String Manipulation**: Substring extraction and replacement
- **Formatting**: Color codes and aligned output

#### System Integration
- **Process Management**: Command execution and return codes
- **Environment Variables**: Path manipulation and directory handling
- **Logging**: File-based output and timestamp generation

---

## Testing and Verification

### Test Cases for Each Script

#### Task 1 - Bubble Sort
- Verify sorting with different array sizes
- Test with already sorted arrays
- Check early termination functionality

#### Task 2 - Password Generator
- Test various password lengths (4, 8, 16, 32, 64, 128)
- Verify character set inclusion
- Check strength analysis accuracy

#### Task 3 - Git Simulator
- Test with new, modified, and deleted files
- Verify status reporting accuracy
- Test repository initialization

#### Task 4 - File Segregation
- Test with mixed file types
- Verify archive creation
- Check file move operations

#### Task 5 - Executable Finder
- Test with various executable types
- Verify logging functionality
- Check statistics accuracy

---

## Conclusion

This lab manual demonstrates comprehensive bash scripting skills including:
- **Algorithm Implementation**: Sorting algorithms and data structures
- **System Utilities**: File operations and process management
- **User Interaction**: Input validation and interactive interfaces
- **Data Processing**: File analysis and report generation
- **Error Handling**: Robust error checking and recovery

Each script follows best practices for bash scripting with proper error handling, user feedback, and documentation. The implementations are designed to be educational while remaining practical and functional.

---

## Screenshots and Output Examples

*Note: When submitting, include actual terminal screenshots showing:*
1. **Task 1**: Bubble sort execution with step-by-step output
2. **Task 2**: Password generation with different lengths and analysis
3. **Task 3**: Git simulator showing init and status operations
4. **Task 4**: File segregation process and final directory structure
5. **Task 5**: Executable finder results and log file contents

*Each screenshot should clearly show the command execution and complete output for full credit.* to Run
```bash
chmod +x task_1.sh
./task_1.sh
```

#### Expected Output
- Original array display
- Step-by-step sorting process
- Final sorted array
- Completion message

---
